var express = require('express');
var myData =  ["Roses","Carnations","Tulips"]


module.exports = myData;



