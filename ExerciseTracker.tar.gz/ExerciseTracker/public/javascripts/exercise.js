var exercise = function(date, move, reps, confid){
    this.date = date;
    this.move = move;
    this.reps = reps;
    this.confid = confid;
}
