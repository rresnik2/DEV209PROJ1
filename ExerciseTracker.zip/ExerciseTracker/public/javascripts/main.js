var exerciseList = [];

var exercise = function (date, move, reps, confid) {
  this.date = date;
  this.move = move;
  this.reps = reps;
  this.confid = confid;
  this.ID = Math.random().toString(16).slice(5);
}


document.addEventListener("DOMContentLoaded", function (event) {


  document.getElementById("submit").addEventListener("click", function () {

    addExercise();
  });

  $(document).on("pagebeforeshow", "#show", function (event) {

    createChart();
    //Render Chart


  });
});

function addExercise() {
  let exerciseTemp = new exercise(document.getElementById("dateDone").value, document.getElementById("exercise").value, parseInt(document.getElementById("reps").value), document.getElementById("confidence").value);
  $.ajax({
    url: "/addExercise",
    type: "POST",
    data: JSON.stringify(exerciseTemp),
    contentType: "application/json; charset=utf-8",
    success: function (result) {
      console.log(result);
      // document.location.href = "index.html#show";
    },
    error: function (xhr, textStatus, errorThrown) {
      alert("Server could not add exercise: " + exerciseTemp.ID);
      alert(textStatus + " " + errorThrown);
    }
  });
}
function sortData(exerciseList, chart) {
  for (var i = 0; i < exerciseList.length; i++) {
    if (exerciseList[i].move === "sld") {
      chart.options.data[0].dataPoints.push({
        x: new Date(exerciseList[i].date),
        y: exerciseList[i].reps
      })
    }
    else if (exerciseList[i].move === "calves") {
      chart.options.data[1].dataPoints.push({
        x: new Date(exerciseList[i].date),
        y: exerciseList[i].reps
      })
    }
    else if (exerciseList[i].move === "kneetap") {
      chart.options.data[2].dataPoints.push({
        x: new Date(exerciseList[i].date),
        y: exerciseList[i].reps
      })
    }
    else if (exerciseList[i].move === "hlr") {
      chart.options.data[3].dataPoints.push({
        x: new Date(exerciseList[i].date),
        y: exerciseList[i].reps
      })
    }
    else if (exerciseList[i].move === "atw") {
      chart.options.data[4].dataPoints.push({
        x: new Date(exerciseList[i].date),
        y: exerciseList[i].reps
      })
    }
    else {
      chart.options.data[5].dataPoints.push({
        x: new Date(exerciseList[i].date),
        y: exerciseList[i].reps
      })
    }
  }
}

function toggleDataSeries(e) {
  if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
    e.dataSeries.visible = false;
  }
  else {
    e.dataSeries.visible = true;
  }

}

function createChart() {
  $.get("/getData", function (data, status) {
    console.log(status);
    exerciseList = data;
    var chart = new CanvasJS.Chart("chartContainer", {
      animationEnabled: true,
      title: {
        text: "Exercise Trends"
      },
      axisX: {
        valueFormatString: "DD MMM, YY"
      },
      axisY: {
        title: "Repetitions of Exercise",
        suffix: " reps"
      },
      legend: {
        cursor: "pointer",
        fontSize: 16,
        itemclick: toggleDataSeries
      },
      toolTip: {
        shared: true
      },
      data: [{
        name: "Single Leg Deadlift",
        type: "spline",
        showInLegend: true,
        dataPoints: [],
        markerSize: 4
      },
      {
        name: "Calf Raises",
        type: "spline",
        showInLegend: true,
        dataPoints: [],
        markerSize: 4
      },
      {
        name: "Plank w/ Knee Taps",
        type: "spline",
        showInLegend: true,
        dataPoints: [],
        markerSize: 4
      },
      {
        name: "Hamstring Lever Release",
        type: "spline",
        showInLegend: true,
        dataPoints: [],
        markerSize: 4
      },
      {
        name: "Around the World",
        type: "spline",
        showInLegend: true,
        dataPoints: [],
        markerSize: 4
      },
      {
        name: "Step March",
        type: "spline",
        showInLegend: true,
        dataPoints: [],
        markerSize: 4
      }
      ]
    });
    if (exerciseList.length !== 0) {
      sortData(exerciseList, chart);
      console.log(chart);
      chart.render();

    }

  })
}



